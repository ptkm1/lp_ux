import React from "react";

interface CaseProps {
  title?: string;
  description?: string;
  image?: string;
  link?: string;
  appStore?: boolean;
  playStore?: boolean;
}

const Case = ({ ...props }: CaseProps) => {
  return (
    <div>
      <div className="group border-t border-[#143B28] border-opacity-100 py-12 transition-colors elevated-links @container first:border-t hover:bg-[#4e4e50]/10 cursor-pointer">
        <div className="container mx-auto px-container flex max-md:flex-col box-border max-md:px-6 max-md:gap-6">
          <div className="flex flex-1 flex-col items-start justify-between w-full gap-10">
            <div className="mr-6">
              <a
                className="elevated-link flex flex-col gap-6"
                href="/projects/dia"
              >
                <h3 className="text-6xl text-slate-400">{props.title}</h3>
                <p className="text-4xl max-w-lg font-extralight">
                  {props.description}
                </p>
              </a>
              <div className="mt-6 flex gap-4 flex-col">
                {props.playStore && (
                  <div className="col-span-1 flex items-center">
                    <img
                      className="mr-2 h-auto w-10 rounded-md bg-background-offset"
                      src="https://static.vecteezy.com/system/resources/previews/022/613/026/original/google-play-store-icon-logo-symbol-free-png.png"
                      alt="Playstore icon"
                      width="168"
                      height="132"
                    />
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-foreground-secondary">
                        Google Playstore
                      </h4>
                      <p className="text-sm font-medium">
                        Disponivel para Android
                      </p>
                    </div>
                  </div>
                )}
                {props.appStore && (
                  <div className="col-span-1 flex items-center">
                    <img
                      className="mr-2 h-auto w-10 rounded-md bg-background-offset"
                      src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/App_Store_%28iOS%29.svg/2048px-App_Store_%28iOS%29.svg.png"
                      alt="ED Award Nominee badge"
                      width="168"
                      height="132"
                    />
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-foreground-secondary">
                        Apple Store
                      </h4>
                      <p className="text-sm font-medium">Disponivel para iOS</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <a
              className="relative inline-flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap text-md font-medium leading-none outline-none transition-all hover:bg-white hover:text-[#122c2e] disabled:pointer-events-none disabled:opacity-60 text-slate-50 border hover: h-11 rounded-md px-5 mt-6"
              href={props.link}
            >
              <span className="">View project</span>
            </a>
          </div>
          <div className="w-5/12 h-[600px] max-md:w-full">
            <img
              className="rounded-lg w-full h-full object-cover"
              src={props.image}
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Case;
