import React from "react";

const Hero: React.FC = () => {
  return (
    <div className="container mx-auto relative h-full">
      <h1 className="mt-10 text-7xl font-bold">
        <span
          style={{ opacity: 1, transform: "translateY(1ch)" }}
          className="mr-1 inline-block transition-all duration-500 ease-motion"
        >
          Think.
        </span>
        <span
          style={{ opacity: 1, transform: "translateY(1ch)" }}
          className="mr-1 inline-block transition-all duration-500 ease-motion"
        >
          Design.
        </span>
        <br />
        <span
          style={{ opacity: 1, transform: "translateY(1ch)" }}
          className="mr-1 inline-block transition-all duration-500 ease-motion"
        >
          Develop.
        </span>
        <span
          style={{ opacity: 1, transform: "translateY(1ch)" }}
          className="mr-1 inline-block transition-all duration-500 ease-motion"
        >
          Launch.
        </span>
        <br />
        <span
          style={{ opacity: 1, transform: "translateY(1ch)" }}
          className="mr-1 inline-block transition-all duration-500 ease-motion text-foreground-secondary"
        >
          Repeat.
        </span>
      </h1>
    </div>
  );
};

export default Hero;
