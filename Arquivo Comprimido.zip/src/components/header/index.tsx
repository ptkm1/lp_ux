import React from "react";

const Header = () => {
  const navigation = [
    { name: "Serviços", href: "#", current: false },
    { name: "Cases", href: "#", current: false },
    { name: "Sobre", href: "#", current: false },
  ];

  return (
    <div className="h-[76px]">
      <header className="ease-[cubic-bezier(0.90, 0, 0.05, 1)] z-30 w-full border-b-[1px] border-[#143B28] border-opacity-100 bg-background/95 backdrop-blur-md transition-[transform,border-color] duration-300 fixed translate-y-0">
        <div className="flex items-center justify-between py-4 container mx-auto px-container">
          <div className="flex items-center gap-2 font-black italic">
            <a aria-label="Go to homepage" href="/">
              _UXMOB
            </a>
          </div>

          <div className="flex items-center gap-8">
            <div className="hidden items-center gap-6 text-base font-medium leading-relaxed md:flex">
              {navigation.map((opt) => (
                <a
                  className="bg-gradient-to-r from-[var(--link-underline-color)] to-[var(--link-underline-color)] bg-[size:0_var(--link-underline-width)] bg-[100%_100%] bg-no-repeat outline-none transition-[background-size] delay-100 duration-300 ease-smooth hover:bg-[size:100%_var(--link-underline-width)] hover:bg-[0_100%] focus-visible:opacity-60 hover:text-[#f5fa9b]"
                  href={opt.href}
                  key={opt.name}
                >
                  {opt.name}
                </a>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden [@media(min-width:400px)]:block">
                <a
                  className="relative inline-flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap text-md font-medium leading-none outline-none transition-all hover:bg-[#f5fa9b] hover:border-[#f5fa9b] hover:text-[#122c2e] disabled:pointer-events-none disabled:opacity-60 text-slate-50 border h-11 rounded-md px-5"
                  href="/get-a-quote"
                >
                  <span className="">Get a quote</span>
                </a>
              </div>
              <button
                className="relative inline-flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap text-md font-medium leading-none outline-none transition-all  hover:bg-[#f5fa9b] hover:border-[#f5fa9b] hover:text-[#122c2e] disabled:pointer-events-none disabled:opacity-60 text-slate-50 border hover: h-11 rounded-md px-5"
                aria-label="Open menu"
              >
                <i data-icon="3dots" aria-hidden="true" className=""></i>
              </button>
            </div>
          </div>
        </div>
      </header>
    </div>
  );
};

export default Header;
