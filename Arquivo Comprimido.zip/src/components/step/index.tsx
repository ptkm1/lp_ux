import React from 'react'

interface StepProps {
    title?: string;
    description?: string;
}

function Step({ title, description }: StepProps) {
    return (
        <div className="flex flex-col">
            <div className="flex items-center justify-between gap-2 mb-10">
                <div className="rounded-full w-[0.75em] h-[0.75em] bg-white left-[1.75rem] top-[0.375rem]"></div>
                <span className="w-full h-[1px] bg-white"></span>
            </div>
            <h2 className=" mb-3 font-semibold text-2xl">{title}</h2>
            <p>{description}</p>
        </div>
    )
}

export default Step