import Header from "@/components/header";
import Case from "@/components/sections/case";
import Hero from "@/components/sections/hero";
import Step from "@/components/step";
import { AtomIcon } from "lucide-react";

const CARDS_SERVICES = [
  {
    id: 1,
    video: "ux_design1.mp4",
    icon: <AtomIcon />,
    title: "UX/UI Design",
    description:
      "Criamos interfaces intuitivas e atraentes, combinando cores, tipografia e elementos visuais para transmitir a identidade da sua marca e melhorar a experiência do usuário.",
  },
  {
    id: 2,
    video: "dev_app1.mp4",
    icon: <AtomIcon />,
    title: "Mobile Apps",
    description:
      "Desenvolvemos aplicativos móveis personalizados, utilizando as melhores tecnologias e frameworks, para garantir um produto final robusto e de alta qualidade.",
  },
  {
    id: 3,
    video: "dev_app.mp4",
    icon: <AtomIcon />,
    title: "WebSites",
    description:
      "Criamos sites responsivos e adaptáveis, com design atraente e navegação intuitiva, para transmitir sua mensagem de forma clara e envolvente aos visitantes.",
  },
  {
    id: 4,
    video: "ux_video.mp4",
    icon: <AtomIcon />,
    title: "Quality Assurance",
    description:
      "Lorem ipsum dolor sit amet, consect adipis elit. Suspendvarius enim in eros element tristique.",
  },
];

export default function Home() {
  return (
    <div className="flex flex-col gap-8 w-full h-full">
      <div className="h-full w-full">
        <Header />

        <Hero />
      </div>

      <div className="h-full w-full container mx-auto mt-52 relative overflow-hidden rounded-lg">
        <div className="w-full h-[70vh] bg-yellow-300 rounded-lg bg-[url('https://a.storyblok.com/f/198185/5760x3240/3f51de3acf/cover-showreel.jpeg/m/0x0/')] bg-no-repeat bg-center bg-cover"></div>
      </div>

      <section className="mt-10 md:mt-14 lg:mt-20">
        <div className="container mx-auto px-container max-md:px-6 mb-20">
          <h2 className="text-5xl">Nossos Cases</h2>
        </div>

        <Case
          title="Gurumed"
          description="O Gurumed é uma plataforma digital que concentra os melhores médicos, dentistas, hospitais e consultórios de Itabuna e Ilhéus em um único App!"
          image="https://source.unsplash.com/random?f=1"
          playStore
          appStore
        />

        <Case
          title="Photoguide"
          description="Aplicativo móvel voltado para pacientes de cirurgia plástica e dermatologia."
          image="https://source.unsplash.com/random?d=1"
          playStore
        />
      </section>

      <section className="mt-10 pt-16 md:mt-14 lg:mt-20 border-t border-[#143B28] border-opacity-100">
        <div className="container mx-auto px-container max-md:px-6 mb-6">
          <h2 className="text-5xl">Nossos Serviços</h2>
        </div>

        <div className="grid grid-cols-4 gap-10 mt-20 max-sm:flex max-sm:flex-col container mx-auto items-center py-12">
          {CARDS_SERVICES.map((a) => (
            <div
              key={a.id}
              className="text-white h-96 w-72 bg-[#b4f6d0]/30 flex flex-col gap-4 items-center justify-between py-4 relative overflow-hidden rounded-xl px-4"
            >
              <video
                autoPlay
                muted
                loop
                poster="aaa"
                className="absolute top-0 left-0 bottom-0 min-h-[100%] min-w-[100%] opacity-30 object-cover"
              >
                <source src={a.video} type="video/mp4" />
              </video>
              <div className="flex flex-col w-full h-16 justify-end">
                {/* <LucideAtom /> */}
                <h1>{a.icon}</h1>
                <h1 className="text-lg font-bold">{a.title}</h1>
              </div>
              <div className="z-10 flex flex-col justify-between gap-2 w-full h-full">
                <p className="text-base">{a.description}</p>
                <a
                  className="relative inline-flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap text-md font-medium leading-none outline-none transition-all hover:bg-white hover:text-[#122c2e] disabled:pointer-events-none disabled:opacity-60 text-slate-50 border hover: h-11 rounded-md px-5 mt-6"
                  href="#"
                >
                  <span className="">Conhecer mais</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>
      <section className="mt-10 pt-16 md:mt-14 lg:mt-20 border-t border-[#143B28] border-opacity-100">
        <div className="container mx-auto px-container mt-32 max-md:px-6 mb-6">
          <h2 className="text-5xl text-center">Processo</h2>
        </div>

        <div className="grid grid-cols-4 gap-10 mt-20 max-sm:flex max-sm:flex-col container mx-auto items-start py-12">
          <Step
            title="Planejamento"
            description="Nosso primeiro passo é o planejamento estratégico. Trabalhamos em estreita colaboração com você para entender suas metas e necessidades. Juntos, definimos uma estratégia clara e traçamos um plano de ação para alcançar o sucesso."
          />
          <Step
            title="Design"
            description="Nossa equipe de designers talentosos criará uma landing page visualmente atraente e envolvente. Utilizamos as melhores práticas de design para garantir que sua página transmita a mensagem certa. Criamos um layout intuitivo, selecionamos imagens impactantes e aplicamos um esquema de cores harmonioso."
          />
          <Step
            title="Desenvolvimento"
            description="Com o planejamento e o design em mãos, avançamos para a etapa de desenvolvimento. Nossa equipe de especialistas utiliza tecnologias avançadas para transformar o conceito em uma landing page funcional. Implementamos o código necessário, otimizamos o desempenho e garantimos que sua página seja responsiva em todos os dispositivos."
          />
          <Step
            title="Deploy"
            description="Após concluirmos o desenvolvimento, é hora de colocar sua landing page no ar. Configuramos um servidor confiável, registramos o domínio e fazemos todo o processo de deploy para garantir que sua página esteja disponível para os visitantes. Realizamos testes rigorosos para garantir a funcionalidade e a compatibilidade, e oferecemos suporte contínuo para manter sua página sempre em pleno funcionamento."
          />
        </div>
      </section>

      <section className="mt-10 pt-16 pb-44 md:mt-14 lg:mt-20 border-t border-[#143B28] border-opacity-100">
        <div className="container mx-auto px-container mt-32 max-md:px-6 mb-6 gap-2 flex flex-col">
          <h2 className="text-3xl text-left text-slate-400">Sobre nós</h2>
          <h1 className="text-5xl text-left">Missões e valores</h1>
        </div>
        <div className="container mx-auto px-container max-md:px-6 mb-6 gap-6 flex flex-col">
          <p className="text-base text-left w-[60%]">
            Não nos levamos muito a sério, mas definitivamente levamos a sério o
            que fazemos. Sim, adoramos nossos trocadilhos de ovos e vamos com
            tudo, em nossa criatividade aleatória e peculiar. Tudo isso enquanto
            nos esforçamos para entregar excelência em tudo o que fazemos.
          </p>
          <button
            className="relative inline-flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap text-md font-medium leading-none outline-none transition-all  hover:bg-[#f5fa9b] hover:border-[#f5fa9b] hover:text-[#122c2e] disabled:pointer-events-none disabled:opacity-60 text-slate-50 border w-max h-11 rounded-md px-5"
            aria-label="Open menu"
          >
            Mais sobre nós
          </button>
        </div>
      </section>

      <section className="mt-10 pt-16 pb-16 md:mt-14 lg:mt-20 border-t border-[#143B28] border-opacity-100">
        
      </section>
    </div>
  );
}
